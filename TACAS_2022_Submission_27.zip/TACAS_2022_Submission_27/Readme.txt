TACAS 2022 Submission #27
For the regular tool paper submission #26 TempAS: A Temporal Verification Tool for Mixed Async-Sync Concurrency

======================================
======================================
========= Build Instructions =========
======================================
======================================

(For all the possible decisions you need to make during the building, just press "enter".)


sudo apt install opam
opam init
eval $(opam env)
opam switch create 4.10.0
eval $(opam env)
sudo apt-get install menhir
sudo apt-get install libgmp-dev
opam install z3 # (this may take a while)
opam install dune

cd Semantics_HIPHOP
eval $(opam env)
dune build


======================================
======================================
======= Functionality Checking =======
======================================
======================================

After the project is compiled, you may start to check validity of the examples demonstrated in the paper.

(Note that there are two main executables, "hip.exe" and "trs.exe". 
"hip.exe" takes programs as input, and makes uses of "trs.exe" as a proving engine. 
"trs.exe" takes entailments as input, to prove/disprove the given entailments. )

# Checking point 1 (hip.exe)
--------------------------------------
Paper           : Sec.4.3 Fig. 7 	
Description     : Mixed Async and Sync Concurrency with Function Calls.   	
Source file     : src/programs/paper_example1.hh   	
Testing command : dune exec ./hip.exe src/programs/paper_example1.hh      	
Expected result : Correct   
--------------------------------------

# Checking point 2 (hip.exe)
--------------------------------------
Paper      	  : Sec.5.1 Fig. 9
Description     : Interference Among Threads.  	
Source file     : src/programs/54_Interference.hh   	
Testing command : dune exec ./hip.exe src/programs/54_Interference.hh  	
Expected result : Correct  
--------------------------------------

# Checking point 3 (hip.exe)
--------------------------------------
Paper      	  : Sec.7.3 Fig. 10      	
Description     : Causality in a Loop.      	
Source file     : src/programs/25_causality.hh      	
Testing command : dune exec ./hip.exe src/programs/25_causality.hh      	 	
Expected result : Correct   
--------------------------------------

# Checking point 4 (hip.exe)
--------------------------------------
Paper      	  : Sec.7.4 Fig. 11      	
Description     : A bug found.      	
Source file     : src/programs/52_Constructiveness.hh      	    	
Testing command : dune exec ./hip.exe src/programs/52_Constructiveness.hh      	
Expected result : Correct    
--------------------------------------

# Checking point 5 (trs.exe)
--------------------------------------
Paper      	  : Sec.6   Table 1      	
Description     : The post condition proving process for Fig. 8.      	
Source file     : src/effects/Mixed_1.ee      	
Testing command : dune exec ./trs.exe src/effects/Mixed_1.ee      	
Expected result : Correct    
--------------------------------------  	      	      	

# Checking point 6 (trs.exe)
--------------------------------------
Paper      	  : Sec.6.1 Table 2      	
Description     : The reoccurrence proving example.      	
Source file     : src/effects/reoccur1.ee      		
Testing command : dune exec ./trs.exe src/effects/reoccur1.ee      	
Expected result : Correct     
--------------------------------------

# Checking point 7 (trs.exe)
--------------------------------------
Paper      	  : Sec.6.2 Table 3      	
Description     : The example for Await.      	
Source file     : src/effects/Wait_1.ee      	   	
Testing command : dune exec ./trs.exe src/effects/Wait_1.ee      	
Expected result : Correct
--------------------------------------


More test files for the Front End are in src/programs/*.hh; and more test files for the Back End are in src/effects/*.ee.
You can also access to our demo page for a better visualisation: http://loris-5.d2.comp.nus.edu.sg/MixedSyncAsync/introduction.html

======================================
======================================
======== Reusability Checking ========
======================================
======================================

The project needs to be built together with a submodule sleek, which is included in the main Semantics_HIPHOP repository.
The sleek submodule implements the back-end, supporting the front-end developed in Semantics_HIPHOP.

Tool structure
Most of the source is boiler plate to tie together parsers, the interesting files are:

ast.ml contains the AST for parsing HipHop.js source file.
sleek/ast.mli contains the AST for parsing Timed Effects Specification.
sleek/checker.ml contains the interface to Z3

hip.ml is the main entrance of the front-end.
trs.ml is the main entrance of the back-end.


======================================
======================================
======== Available Checking ==========
======================================
======================================

If the paper is accepted, the artifact will be made publicly available from:
Github: https://github.com/songyahui/Semantics_HIPHOP
Zenodo: https://zenodo.org/record/5607153#.YX0ECi0RrOQ
-----------
- Cite as -
-----------
Yahui Song. (2021). TempAS: A Temporal Verification Tool for Mixed Async-Sync Concurrency (Artifact). Zenodo. https://doi.org/10.5281/zenodo.5607153



Lastly, thanks for your efforts reviewing our artifact submission! 
