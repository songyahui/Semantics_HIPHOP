First of all, thank you so much for your efforts in evaluating our artifact. 

We are so sorry that our submission was not in the required format. 

For that, we had read through the instructions and prepared the revised submission. Here is the new download link: 

https://drive.google.com/file/d/1lmeHIgXLyBmOmlg4bGnfGvDlH14wQVLN/view?usp=sharing

We would appreciate it a lot if you could take this revised submission into consideration. 



### Response to Review 1:

- In this revised submission, we have included the license as required. 
- We just realized that the provided VM does not have OCaml environment. For that, we have added instructions for building up all the dependencies based on the VM provided. Sorry about the confusion.  

- We indeed stored our artifact in Zenodo:
https://zenodo.org/record/5607153#.YX0ECi0RrOQ
    "Yahui Song. (2021). TempAS: A Temporal Verification Tool for Mixed Async-Sync Concurrency (Artifact). Zenodo. https://doi.org/10.5281/zenodo.5607153"



### Response to Review 2:

- We are sorry that you had to figure out the "opam install dune" yourself. For that, we provide more complete instructions in this revised submission. We have added "opam install dune" to the Github Readme as well. 

- From what I understood, the warnings come from the compilation process when executing "dune build" due to the parsing process. 

- Thanks for noticing that there is a difference between "(RESULT) SUCCESS Verdict Correct" and "(RESULT) SUCCESS".
  After the compilation, there are two main executables, "hip.exe" and "trs.exe". "hip.exe" takes programs as input and makes use of "trs.exe" as a proving engine. "trs.exe" takes entailments as input to prove/disprove the given entailments. 
  We have seven checking points in the paper. The first four are for "hip.exe", while the last three are for "trs.exe". 
  The printing message "(RESULT) SUCCESS" indicates that the current entailment is proved. The extra "Verdict Correct" indicates the proving result "SUCCESS or FAIL" is correct w.r.t whether it is supposed to be "SUCCESS or FAIL". 

  We will expect all the entailments generated to hold in the first 4 test cases for "hip.exe". Therefore, no "Verdict Correct" is printed. But in the last 3 test cases for "trs.exe", we check if the actual entailment result is expected or not. Here are two examples for the entailments input; the "true" and "false" are the verdicts. 

    * ```True && {A}.{B}^*.{C}^*  |-  True && {A}^*.{B}^*.{C}^* : true```;
    * ```True && {A}.{B}^*.{C}^*  |-  True && {A}^*.{B, C}^*    : false```;
  




### Response to Review 3:
- Sorry for the inconvenience; that is our bad for did not follow the submission instructions. For that, we had included the source code directly in the revised submission. 


